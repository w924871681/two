# Final CMC LaTeX submission source

The four independent projects contain main.tex, necessary styles/templates,
all actually used figures, and bibliography sources. Compile from each project
directory with pdflatex. Only 01_Clean requires BibTeX. The other projects have
explicit, synchronized reference entries. Run build_all.py for the checked build.
The Supplement shares the 30 current main-reference numbers; all 30 are actually
cited in the main paper. The restored .bib library has 42 unique entries; unused
historical items are not printed. No nocite-all padding is used.

00_Fig2_Editable_Artwork contains the full new editable vector source, SVG, PDF,
1200 dpi RGB TIFF, previews and generation record. Its optional Python drawing
dependencies are distinct from standard TeX requirements for compiling papers.
No model weights, experiment logs, fonts or original research paths are needed
to compile these four manuscripts. Scientific reproduction assets are separate.
Tracked compares the original fourteen-page submission and uses complete old/new
blocks. Changes to Clean in a future revision require a corresponding true diff;
the delivered Tracked already matches this final Clean after accepting changes.
