from pathlib import Path
import shutil,subprocess
R=Path(__file__).resolve().parent
for folder in ['01_Clean','02_Tracked','03_Rebuttal','04_Supplement']:
    if folder=='04_Supplement':
        shutil.copy2(R/'01_Clean/main.bbl',R/'04_Supplement/bibliography/main_references.tex')
    for engine in (['pdflatex','bibtex','pdflatex','pdflatex'] if folder=='01_Clean' else ['pdflatex']*3):
        cmd=[engine,'main'] if engine=='bibtex' else [engine,'-recorder','-interaction=nonstopmode','-halt-on-error','main.tex']
        subprocess.run(cmd,cwd=R/folder,check=True)
